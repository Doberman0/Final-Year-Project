THESE SCENES USE STANDARD ASSETS NOT INCLUDED IN THE PACKAGE

Import Environment and Character packages before opening.